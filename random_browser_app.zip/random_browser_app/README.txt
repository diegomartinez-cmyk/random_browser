RANDOM BROWSER
================

Es una mini aplicación de navegador hecha con Electron.

FUNCIONES
- Barra de direcciones y buscador.
- Roblox, YouTube, Instagram y TikTok como accesos rápidos.
- Atrás, adelante, recargar e inicio.
- No mantiene un historial propio.
- Usa una sesión persistente para que las páginas compatibles puedan conservar cookies e inicios de sesión.
- Las páginas que bloqueen ciertos accesos, ventanas o funciones por sus propias políticas seguirán teniendo esas limitaciones.

INSTALACIÓN
1. Instala Node.js.
2. Abre una terminal dentro de esta carpeta.
3. Ejecuta: npm install
4. Ejecuta: npm start

IMPORTANTE
Este proyecto es el código fuente de la aplicación. No es todavía un .exe/.apk empaquetado.
