
const { app, BrowserWindow, session, Menu } = require("electron");
const path = require("path");

function createWindow() {
  const win = new BrowserWindow({
    width: 1200,
    height: 800,
    minWidth: 700,
    minHeight: 500,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      webviewTag: true
    }
  });

  win.loadFile("browser.html");
  Menu.setApplicationMenu(null);
}

app.whenReady().then(() => {
  // No guardamos un historial propio. Las cookies/sesiones se mantienen
  // durante el uso normal para permitir iniciar sesión en sitios compatibles.
  createWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
